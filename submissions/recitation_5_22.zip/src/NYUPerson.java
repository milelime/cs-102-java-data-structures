
public abstract class NYUPerson {
  public String name = "???";

  public void sendemail(String message) {
    // send an email with above message with priority normal

    System.out.println("NYUPerson class " + message);
  }
}
